package Homework.Homework01;

public class Java02 {
    public static void main(String[] args) {
        System.out.println("\\n                Line break.\n"
        + "\\t                Tabulation.\n"
        + "\\'              Single Quote.\n"
        + "\\\"              Double Quote.\n"
        + "\\\\                     \\sign.\n"
        + "\\\\\\                   \\\\sign.\n"
        + "//              Line Comment.\n"
        + "/* ...  */     Black Comment.\n"
        + "\"\"\"                   \n"
        + "                  Text block.\n"
        + "\"\"\"                   \n");
    }
}
