package Homework.Homework01;
public class Java01 {
    public static void main(String[] args) {
        System.out.printf("Hello %s","Mouylang");
    }
}
